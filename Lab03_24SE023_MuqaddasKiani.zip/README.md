# ML Lab 03 – Pandas

## Description
This lab focuses on data analysis and cleaning using the Python Pandas library. The dataset contains used car advertisements from Pakistan.

## Tools Used
- Python
- Pandas
- Jupyter Notebook
- VS Code

## Files Included
- `Lab03_Starter.ipynb` – Completed lab notebook with code and outputs.
- `pakistan_used_cars_clean.csv` – Cleaned dataset generated in Task 5.

## Tasks Completed
- Reading and exploring CSV data
- Selecting and filtering data
- Handling missing values
- Removing duplicate records
- Cleaning incorrect values
- Data analysis and price comparisons
- Saving the cleaned dataset
- Reflection